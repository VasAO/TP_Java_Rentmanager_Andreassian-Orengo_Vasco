------------------------------------------------------------------------------------
Pour lancer le programme, lancer dans le dossier qui contient le projet :
		mvn exec:java 
	Afin de créer la base de donnée.
		mvn clean install tomcat7:run
	Afin de pouvoir accéder à l'application web et de lancer les tests.
	Les tests ajoutant déjà une reservation dans la base de donnée,
	il est important qu'elle soit initialisée.

Par la suite, si l'on souhaite relancer le programme, un mvn tomcat7:run suffira.
------------------------------------------------------------------------------------

Problèmes rencontrés et solutions.

Au début du projet, parce que j'avais perdu l'habitude de travailler avec java, 
j'ai pris énormément de retard et c'est en grande partie pour cette raison que
je n'ai pas de CLI. En réalité, parce qu'une grosse partie des commandes ne
m'étaient pas connu (comme par exemple celles qui lient les parties SQL ou Web), 
il a été nécessaire de bien prendre le temps de comprendre de quoi on parle et, à
quoi elles servent.

De la même manière, j'ai mis un peu de temps (un ou deux jours) à me réhabituer
au requêtes SQL.

Néanmoins, une fois lancé, il a été assez facile d'avancer sans trops de problèmes
en rencontrant une erreur un peu plus tordue de temps en temps sans que ce soit
vraiment bloquant. Suite à une de ces erreurs, et après vous avoir posé la question
il a été plus simple de lire les rapports d'erreurs et ainsi pouvoir avancer avec
encore plus d'autonomie.

L'essai de l'implémentation de Spring à mon code n'a rien donné, ne comprenant pas
vraiment comment tout cela marche et venant à manquer de temps, je n'ai pas pu
l'ajouter à mon code tout en le gardant fonctionnel.

A l'inverse, l'utilisation de tests (avec ou sans Mockito) a été plutôt facile même
si je n'ai pas du tout utilisé cette fonctionnalité avant d'en apprendre l'existance.
De plus, ces tests sont des essais très limités puisque nous les construisons avec
la même vision de comment fonctionnent notre code, je n'en donc ai pas vu une grande
utilité.

Enfin, j'ai mis un peu de temps à faire fonctionner les fonctions de vérifications
de saisie des données (comme pour vérifier la limite des 30 jours ou qu'un véhicule
ne peut pas être réservé par deux personnes en même temps). Mais ces problèmes ont
été résolus par la suite même si je trouve que les fonctions correspondantes sont 
plus brouillonnes. Comme la mise à jour d'une entrée et la création se ressemble,
on garde les mêmes fonctions de vérifications d'entrée. Pour écrire moins de lignes,
on appelle donc la fonction de vérification de la mise à jour d'un profil dans celle
de création en ajoutant les vérifications supplémentaires.