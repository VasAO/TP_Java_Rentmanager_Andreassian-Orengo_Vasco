package com.epf.rentmanager.ui;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.epf.rentmanager.exceptions.ServiceException;
import com.epf.rentmanager.model.Reservation;
import com.epf.rentmanager.service.ClientService;
import com.epf.rentmanager.service.RentService;
import com.epf.rentmanager.service.VehicleService;

@WebServlet("/rents/create")
public class RentCreateServlet extends HttpServlet{
	
	private RentService rs = RentService.getInstance();
	private ClientService cs = ClientService.getInstance();
	private VehicleService vs = VehicleService.getInstance();
	private ServiceException sException = ServiceException.getInstance();
	
	private DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	
	protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {

		final RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/rents/create.jsp");
		
		try {
			request.setAttribute("cars", vs.findAll());
			request.setAttribute("clients", cs.findAll());
		} catch (final ServiceException e) {
			request.setAttribute("error", e.getMessage());
			dispatcher.forward(request,  response);	
		}
		dispatcher.forward(request,  response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		try {
			sException.checkError(request.getParameter("car"), request.getParameter("client"), request.getParameter("begin"), request.getParameter("end"));
			
			Reservation r = new Reservation(vs.findById(Integer.parseInt(request.getParameter("car"))),
					cs.findById(Integer.parseInt(request.getParameter("client"))),  
					LocalDate.parse(request.getParameter("begin"), format), 
					LocalDate.parse(request.getParameter("end"), format));			
			rs.create(r);
			
			response.sendRedirect("http://localhost:8080/rentmanager/rents");
		
		} catch (final ServiceException e) {
			request.setAttribute("error", e.getMessage());
			doGet(request,  response);	
		}
	}
}
