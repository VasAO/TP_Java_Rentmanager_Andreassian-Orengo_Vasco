package com.epf.rentmanager.exceptions;

public class ServiceException extends Exception{
	
	public static ServiceException instance = null;
	
	private ServiceException() {}
	
	public static ServiceException getInstance() {
		if (instance == null) {
			instance = new ServiceException();
		}
		return instance;
	}
	
	public ServiceException(String message) {
		super(message);
	}
	
	/**
	 * On vérifie que les champs récupérés ne sont pas vides.
	 * @param str1
	 * @param str2
	 * @param str3
	 * @param str4
	 * @throws ServiceException
	 */
	public void checkError(String str1, String str2, String str3, String str4) throws ServiceException{
		
		if(str1.isEmpty() || str2.isEmpty() || str3.isEmpty() || str4.isEmpty()) {
			throw new ServiceException("Veuillez remplir tous les champs.");
		}
	}
	
	public void checkError(String str1, String str2, String str3) throws ServiceException{
		
		if (str1.isEmpty() || str2.isEmpty() || str3.isEmpty()) {
			throw new ServiceException("Veuillez remplir tous les champs.");
		}
	}
}
