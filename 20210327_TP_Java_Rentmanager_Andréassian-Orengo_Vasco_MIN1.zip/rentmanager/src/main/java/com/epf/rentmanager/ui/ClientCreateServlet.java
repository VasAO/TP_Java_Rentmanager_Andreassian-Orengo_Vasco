package com.epf.rentmanager.ui;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.epf.rentmanager.exceptions.ServiceException;
import com.epf.rentmanager.service.ClientService;
import com.epf.rentmanager.model.Client;

@WebServlet("/users/create")
public class ClientCreateServlet extends HttpServlet {
	
	private ClientService cs = ClientService.getInstance();
	private ServiceException sException = ServiceException.getInstance();
	
	private DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	
	protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {

		final RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/users/create.jsp");
		request.setAttribute("action", "create");
		dispatcher.forward(request,  response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		final RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/users/create.jsp");
		
		try {
			sException.checkError(request.getParameter("last_name"), request.getParameter("first_name"), request.getParameter("email"), request.getParameter("naissance"));
			
			Client c = new Client(request.getParameter("last_name"), request.getParameter("first_name"), 
					request.getParameter("email"), LocalDate.parse(request.getParameter("naissance"), format));
			cs.create(c);
			
			response.sendRedirect("http://localhost:8080/rentmanager/users");
			
		} catch (final ServiceException e) {
			request.setAttribute("error", e.getMessage());
			dispatcher.forward(request,  response);	
		}
	}
}
