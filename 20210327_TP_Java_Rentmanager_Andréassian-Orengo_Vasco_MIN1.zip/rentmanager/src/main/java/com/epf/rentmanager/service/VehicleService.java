package com.epf.rentmanager.service;

import java.util.List;

import com.epf.rentmanager.exceptions.DaoException;
import com.epf.rentmanager.exceptions.ServiceException;
import com.epf.rentmanager.model.Reservation;
import com.epf.rentmanager.model.Vehicle;
import com.epf.rentmanager.dao.ReservationDao;
import com.epf.rentmanager.dao.VehicleDao;

public class VehicleService {

	private VehicleDao vehicleDao;
	public static VehicleService instance;
	
	private VehicleService() {
		this.vehicleDao = VehicleDao.getInstance();
	}
	
	public static VehicleService getInstance() {
		if (instance == null) {
			instance = new VehicleService();
		}

		return instance;
	}

	private DaoException daoE = DaoException.getInstance();
	private ReservationDao resDao = ReservationDao.getInstance();
	
	/**
	 * On appelle la fonction de vérification avant de return
	 * @param v
	 * @return l'id du véhicule créé
	 * @throws ServiceException
	 */
	public long create(Vehicle v) throws ServiceException {
		try {
			daoE.checkVehicle(v);
			return vehicleDao.create(v);
		} catch (DaoException e) {
			throw new ServiceException(e.getMessage());
		}
	}
	
	/**
	 * On appelle la fonction de vérification avant de return
	 * @param v
	 * @return l'id de l'entrée mise à jour
	 * @throws ServiceException
	 */
	public long update(Vehicle v) throws ServiceException {
		try {
			daoE.checkVehicle(v);
			return vehicleDao.update(v);
		} catch (DaoException e) {
			throw new ServiceException(e.getMessage());
		}
	}
	
	/**
	 * On supprime l'entrée ainsi que les réservations assoicées.
	 * @param id
	 * @return l'identifiant de l'entrée supprimée
	 * @throws ServiceException
	 */
	public long deleteById(int id) throws ServiceException {
		try {
			deleteAssociatedRent(resDao.findResaByVehicleId(id));
			return vehicleDao.deleteById(id);
		} catch (DaoException e) {
			throw new ServiceException(e.getMessage());
		}
	}
	
	/**
	 * @param rList
	 * @throws ServiceException
	 */
	public void deleteAssociatedRent(List<Reservation> rList) throws ServiceException{
		try {
			for (int i = 0; i < rList.size(); i++) {
				resDao.deleteById(rList.get(i).getId());
			}
		} catch (DaoException e) {
			throw new ServiceException(e.getMessage());
		}
	}
	
	/**
	 * @param id
	 * @return l'entrée trouvée
	 * @throws ServiceException
	 */
	public Vehicle findById(int id) throws ServiceException {
		try {
			return vehicleDao.findById(id);
		} catch (DaoException e) {
			throw new ServiceException(e.getMessage());
		}
	}
	
	/**
	 * @return la liste de tous les véhicules
	 * @throws ServiceException
	 */
	public List<Vehicle> findAll() throws ServiceException {
		try {
			return vehicleDao.findAll();
		} catch (Exception e) {
			throw new ServiceException("Une erreur Service est survenue :" + e.getMessage());
		}
	}
	
	/**
	 * @return le nombre de véhicules
	 * @throws ServiceException
	 */
	public long count() throws ServiceException {
		try {
			return (vehicleDao.findAll()).size();
		} catch (DaoException e) {
			throw new ServiceException(e.getMessage());
		}
	}
}
