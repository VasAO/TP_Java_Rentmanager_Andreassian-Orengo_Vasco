package com.epf.rentmanager.service;

import java.util.List;

import com.epf.rentmanager.dao.ClientDao;
import com.epf.rentmanager.dao.ReservationDao;
import com.epf.rentmanager.exceptions.DaoException;
import com.epf.rentmanager.exceptions.ServiceException;
import com.epf.rentmanager.model.Client;
import com.epf.rentmanager.model.Reservation;

public class ClientService {

	private ClientDao clientDao;
	public static ClientService instance;
	
	private ClientService() {
		this.clientDao = ClientDao.getInstance();
	}
	
	public static ClientService getInstance() {
		if (instance == null) {
			instance = new ClientService();
		}
		return instance;
	}
	
	private DaoException daoE = DaoException.getInstance();
	private ReservationDao resDao = ReservationDao.getInstance();
	
	/**
	 * On supprime l'entrée ainsi que les réservations assoicées.
	 * @param id
	 * @return
	 * @throws ServiceException
	 */
	public long deleteById(int id) throws ServiceException {
		try {
			deleteAssociatedRent(resDao.findResaByClientId(id));
			return clientDao.deleteById(id);
		} catch (DaoException e) {
			throw new ServiceException(e.getMessage());
		}
	}
	
	/**
	 * @param rList
	 * @throws ServiceException
	 */
	public void deleteAssociatedRent(List<Reservation> rList) throws ServiceException{
		try {
			for (int i = 0; i < rList.size(); i++) {
				resDao.deleteById(rList.get(i).getId());
			}
		} catch (DaoException e) {
			throw new ServiceException(e.getMessage());
		}
	}
	
	/**
	 * On appelle la fonction de vérification avant de reurn
	 * @param c
	 * @return l'id du client modifié
	 * @throws ServiceException
	 */
	public long create(Client c) throws ServiceException {
		try {
			daoE.checkClient(c);
			return clientDao.create(c);
		} catch (DaoException e) {
			throw new ServiceException(e.getMessage());
		}
	}
	
	/**
	 * On appelle la fonction de vérification avant de return
	 * @param c
	 * @return l'entrée mise à jour
	 * @throws ServiceException
	 */
	public long update(Client c) throws ServiceException {
		try {
			daoE.checkUpdateClient(c);
			return clientDao.update(c);
		} catch (DaoException e) {
			throw new ServiceException(e.getMessage());
		}
	}
	
	/**
	 * @param id
	 * @return le client avec cette id
	 * @throws ServiceException
	 */
	public Client findById(int id) throws ServiceException {
		try {
			return clientDao.findById(id);
		} catch (DaoException e) {
			throw new ServiceException(e.getMessage());
		}
	}
	
	/**
	 * @return tous les clients
	 * @throws ServiceException
	 */
	public List<Client> findAll() throws ServiceException {
		try {
			return clientDao.findAll();
		} catch (DaoException e) {
			throw new ServiceException(e.getMessage());
		}
	}
	
	/**
	 * 
	 * @return le nombre de clients
	 * @throws ServiceException
	 */
	public long count() throws ServiceException {
		try {
			return (clientDao.findAll()).size();
		} catch (DaoException e) {
			throw new ServiceException(e.getMessage());
		}
	}
}
