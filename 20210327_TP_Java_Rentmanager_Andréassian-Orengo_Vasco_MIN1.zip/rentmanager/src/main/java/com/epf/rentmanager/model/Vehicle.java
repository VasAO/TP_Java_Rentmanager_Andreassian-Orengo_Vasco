package com.epf.rentmanager.model;

public class Vehicle {
	private int id;
	private String constructeur;
	private String modele;
	private short nb_places;
	
	public Vehicle() {
		
	}
	
	public Vehicle(int id, String constructeur, String modele, short nb_places) {
		this(constructeur, modele, nb_places);
		this.id = id;
	}
	
	public Vehicle(String constructeur, String modele, short nb_places) {
		this.constructeur = constructeur;
		this.modele = modele;
		this.nb_places = nb_places;
	}
	
	// Getters
	public int getId() {
		return id;
	}
	
	public String getConstructeur() {
		return constructeur;
	}
	
	public String getModele() {
		return modele;
	}
	
	public short getNb_places() {
		return nb_places;
	}
	
	// Setters
	public void setId(int id) {
		this.id = id;
	}
	
	public void setConstructeur(String constructeur) {
		this.constructeur = constructeur;
	}
	
	public void setModele(String modele) {
		this.modele = modele;
	}
	
	public void setNb_places(short nb_places) {
		this.nb_places = nb_places;
	}
	
	public void equals(Vehicle v) {
		this.id = v.id;
		this.constructeur = v.constructeur;
		this.modele = v.modele;
		this.nb_places = v.nb_places;
	}
}
