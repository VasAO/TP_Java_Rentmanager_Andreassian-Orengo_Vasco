package com.epf.rentmanager.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.epf.rentmanager.exceptions.DaoException;
import com.epf.rentmanager.model.Vehicle;
import com.epf.rentmanager.persistence.ConnectionManager;

public class VehicleDao {
	
	private static VehicleDao instance = null;
	private VehicleDao() {}
	public static VehicleDao getInstance() {
		if(instance == null) {
			instance = new VehicleDao();
		}
		return instance;
	}
	
	private static final String CREATE_VEHICLE_QUERY = "INSERT INTO Vehicle(constructeur, modele, nb_places) VALUES(?, ?, ?);";
	private static final String DELETE_VEHICLE_QUERY = "DELETE FROM Vehicle WHERE id=?;";
	private static final String FIND_VEHICLE_QUERY = "SELECT id, constructeur, modele, nb_places FROM Vehicle WHERE id=?;";
	private static final String FIND_VEHICLES_QUERY = "SELECT id, constructeur, modele, nb_places FROM Vehicle;";
	private static final String UPDATE_VEHICLE_QUERY = "UPDATE Vehicle SET id=?, constructeur=?, modele=?, nb_places=? WHERE id=?";
	
	/**
	 * On récupère les erreurs SQL levées et on utilise la requête SQL adéquate
	 * @param vehicle
	 * @return l'id de l'entrée créée
	 * @throws DaoException
	 */
	public int create(Vehicle vehicle) throws DaoException {
		try (
            Connection connection = ConnectionManager.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(CREATE_VEHICLE_QUERY, Statement.RETURN_GENERATED_KEYS);
        ) {
            preparedStatement.setString(1, vehicle.getConstructeur());
            preparedStatement.setString(2, vehicle.getModele());
            preparedStatement.setInt(3, vehicle.getNb_places());
            preparedStatement.executeUpdate();
            
            ResultSet resultSet = preparedStatement.getGeneratedKeys();
            if(resultSet.next()) {
                int id = resultSet.getInt(1);
                return id;
            } else {
                throw new DaoException("Erreur lors de la création du vehicule.");
            }
        } catch(SQLException e) {
            throw new DaoException("Erreur VehicleDao createClient" + e.getMessage());
        }
	}
	
	/**
	 * On récupère les erreurs SQL levées et on utilise la requête SQL adéquate
	 * @param v
	 * @return l'id de l'entrée créée
	 * @throws DaoException
	 */
	public long update(Vehicle v) throws DaoException {

		try (
				Connection connection = ConnectionManager.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_VEHICLE_QUERY, Statement.RETURN_GENERATED_KEYS);
			){
			preparedStatement.setInt(1, v.getId());
			preparedStatement.setString(2, v.getConstructeur());
			preparedStatement.setString(3, v.getModele());
			preparedStatement.setInt(4, v.getNb_places());
			preparedStatement.setInt(5, v.getId());
			preparedStatement.executeUpdate();
			
			ResultSet resultSet = preparedStatement.getGeneratedKeys();
			if(resultSet.next()) {
				return resultSet.getInt(1);
			} else {
				throw new DaoException("Erreur dans la mise à jour du vehicle.");
			}
			
		} catch (SQLException e) {
			throw new DaoException("Une erreur SQL est survenue : " + e.getMessage());
		}
	}
	
	/**
	 * On récupère les erreurs SQL levées et on utilise la requête SQL adéquate
	 * @param id
	 * @return l'id de l'entrée supprimée
	 * @throws DaoException
	 */
	public long deleteById(int id) throws DaoException {
		try (
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(DELETE_VEHICLE_QUERY);
			){
			preparedStatement.setInt(1, id);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			throw new DaoException(e.getMessage());
		}
		return id;
	}	
	
	/**
	 * On récupère les erreurs SQL levées et on utilise la requête SQL adéquate
	 * @param id
	 * @return le véhicule trouvé
	 * @throws DaoException
	 */
	public Vehicle findById(int id) throws DaoException {
		Vehicle v = new Vehicle();
		
		try (
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(FIND_VEHICLE_QUERY);
		){
			preparedStatement.setInt(1, id);
			ResultSet resultSet = preparedStatement.executeQuery();
			
			if (resultSet.next()){
				v.setId(id);
				v.setConstructeur(resultSet.getString("constructeur"));
				v.setModele(resultSet.getString("modele"));
				v.setNb_places(resultSet.getShort("nb_places"));
			}
			resultSet.close();
			
		} catch (SQLException e) {
			throw new DaoException("Une erreur est survenue : " + e.getMessage());
		}
		return v;
	}
	
	/**
	 * On récupère les erreurs SQL levées et on utilise la requête SQL adéquate
	 * @return la liste de tous les véhicules
	 * @throws DaoException
	 */
	public List<Vehicle> findAll() throws DaoException {
		List<Vehicle> result = new ArrayList<>();
		try {
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(FIND_VEHICLES_QUERY);
			
			ResultSet resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				Vehicle vehicle = new Vehicle();
				vehicle.setId(resultSet.getInt("id"));
				vehicle.setConstructeur(resultSet.getString("constructeur"));
				vehicle.setModele(resultSet.getString("modele"));
				vehicle.setNb_places(resultSet.getShort("nb_places"));
				result.add(vehicle);
			}
			resultSet.close();
			preparedStatement.close();
			connection.close();
			
		}catch (SQLException e) {
			throw new DaoException("Une erreur DAO est survenue :" + e.getMessage());
		}
		return result;
	}
	
}
