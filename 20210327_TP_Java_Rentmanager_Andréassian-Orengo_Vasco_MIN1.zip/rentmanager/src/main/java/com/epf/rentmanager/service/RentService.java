package com.epf.rentmanager.service;

import java.util.List;

import com.epf.rentmanager.dao.ReservationDao;
import com.epf.rentmanager.exceptions.DaoException;
import com.epf.rentmanager.exceptions.ServiceException;
import com.epf.rentmanager.model.Reservation;

public class RentService {
	
	private ReservationDao resDao;
	public static RentService instance;
	
	private RentService() {
		this.resDao = ReservationDao.getInstance();
	}
	
	public static RentService getInstance() {
		if(instance == null) {
			instance = new RentService();
		}
		return instance;
	}
	
	private DaoException daoE = DaoException.getInstance();
	
	/**
	 * On appelle la fonction de vérificationa avant de return
	 * @param r
	 * @return l'id de l'entrée créée
	 * @throws ServiceException
	 */
	public long create(Reservation r) throws ServiceException {
		try {
			daoE.checkRent(r);
			return resDao.create(r);
		} catch (DaoException e) {
			throw new ServiceException(e.getMessage());
		}
	}
	
	/**
	 * On appelle la fonction de vérificationa avant de return
	 * @param r
	 * @return l'id de l'entrée mise à jour
	 * @throws ServiceException
	 */
	public long update(Reservation r) throws ServiceException {
		try {
			daoE.checkUpdateRent(r);
			return resDao.create(r);
		} catch (DaoException e) {
			throw new ServiceException(e.getMessage());
		}
	}
	
	/**
	 * On supprime l'entrée.
	 * @param id
	 * @return l'idée de l'entrée supprimée
	 * @throws ServiceException
	 */
	public long deleteById(int id) throws ServiceException{
		try {
			return resDao.deleteById(id);
		} catch (DaoException e) {
			throw new ServiceException(e.getMessage());
		}
	}
	
	/**
	 * @param clientId
	 * @return la liste de toutes les réservations avec le client en question
	 * @throws ServiceException
	 */
	public List<Reservation> findResaByClientId(long clientId) throws ServiceException {
		try {
			return resDao.findResaByClientId(clientId);
		} catch (DaoException e) {
			throw new ServiceException(e.getMessage());
		}
	}
	
	/**
	 * @param vehicleId
	 * @return la liste de toutes les réservations avec le véhicule en question
	 * @throws ServiceException
	 */
	public List<Reservation> findResaByVehicleId(long vehicleId) throws ServiceException {
		try {
			return resDao.findResaByVehicleId(vehicleId);
		} catch (DaoException e) {
			throw new ServiceException(e.getMessage());
		}
	}
	
	/**
	 * @return la liste de toutes les réservations
	 * @throws ServiceException
	 */
	public List<Reservation> findAll() throws ServiceException {
		try {
			return resDao.findAll();
		} catch (DaoException e) {
			throw new ServiceException("Une erreur Service est survenue : " + e.getMessage());
		}
	}
	/**
	 * @return le nombre de réservations
	 * @throws ServiceException
	 */
	public long count() throws ServiceException {
		try {
			return (resDao.findAll()).size();
		} catch (DaoException e) {
			throw new ServiceException(e.getMessage());
		}
	}
}
