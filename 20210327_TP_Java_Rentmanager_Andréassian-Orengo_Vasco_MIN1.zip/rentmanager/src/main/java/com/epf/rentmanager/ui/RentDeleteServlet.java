package com.epf.rentmanager.ui;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.epf.rentmanager.exceptions.ServiceException;
import com.epf.rentmanager.service.ClientService;
import com.epf.rentmanager.service.RentService;
import com.epf.rentmanager.service.VehicleService;

@WebServlet("/rents/delete")
public class RentDeleteServlet extends HttpServlet {

	RentService rs = RentService.getInstance();
	
	protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
	
		try {
			rs.deleteById(Integer.parseInt(request.getParameter("id")));
		} catch (final ServiceException e) {
			request.setAttribute("error", e.getMessage());
			response.sendRedirect("http://localhost:8080/rentmanager/rents");
		}
		response.sendRedirect("http://localhost:8080/rentmanager/rents");
	}
}
