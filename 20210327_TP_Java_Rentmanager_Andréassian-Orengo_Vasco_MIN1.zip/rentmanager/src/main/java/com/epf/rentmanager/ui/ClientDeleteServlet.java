package com.epf.rentmanager.ui;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.epf.rentmanager.service.ClientService;
import com.epf.rentmanager.exceptions.ServiceException;

@WebServlet("/users/delete")
public class ClientDeleteServlet extends HttpServlet {
	
	private ClientService cs = ClientService.getInstance();
	
	protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {

		try {
			cs.deleteById(Integer.parseInt(request.getParameter("id")));
			
		} catch (final ServiceException e) {
			request.setAttribute("error", e.getMessage());
			response.sendRedirect("http://localhost:8080/rentmanager/users");
		}
		response.sendRedirect("http://localhost:8080/rentmanager/users");
	}
}
