package com.epf.rentmanager.ui;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.epf.rentmanager.exceptions.ServiceException;
import com.epf.rentmanager.service.ClientService;
import com.epf.rentmanager.service.RentService;
import com.epf.rentmanager.service.VehicleService;

@WebServlet("/home")
public class HomeServlet extends HttpServlet {
	
	private ClientService cs = ClientService.getInstance();
	private RentService rs = RentService.getInstance();
	private VehicleService vs = VehicleService.getInstance();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/home.jsp");
		
		try {
			request.setAttribute("nbClients", cs.count());
			request.setAttribute("nbVehicles", vs.count());
			request.setAttribute("nbRents", rs.count());
		} catch (final ServiceException e) {
			System.out.println(e.getMessage());
		}
		dispatcher.forward(request, response);
	}
}