package com.epf.rentmanager.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import com.epf.rentmanager.exceptions.DaoException;
import com.epf.rentmanager.model.Reservation;
import com.epf.rentmanager.persistence.ConnectionManager;

public class ReservationDao {

	private static ReservationDao instance = null;
	
	private ReservationDao() {}
	
	public static ReservationDao getInstance() {
		
		if(instance == null) {
			instance = new ReservationDao();
		}
		return instance;
	}

	private ClientDao cDao = ClientDao.getInstance();
	private VehicleDao vDap = VehicleDao.getInstance();
	 
	private DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ss");
	
	private static final String CREATE_RESERVATION_QUERY = "INSERT INTO Reservation(client_id, vehicle_id, debut, fin) VALUES(?, ?, ?, ?);";
	private static final String DELETE_RESERVATION_QUERY = "DELETE FROM Reservation WHERE id=?;";
	private static final String FIND_RESERVATIONS_BY_CLIENT_QUERY = "SELECT id, vehicle_id, debut, fin FROM Reservation WHERE client_id=?;";
	private static final String FIND_RESERVATIONS_BY_VEHICLE_QUERY = "SELECT id, client_id, debut, fin FROM Reservation WHERE vehicle_id=?;";
	private static final String FIND_RESERVATIONS_QUERY = "SELECT id, client_id, vehicle_id, debut, fin FROM Reservation;";
	private static final String FIND_RESERVATION_QUERY = "SELECT id, client_id, vehicle_id, debut, fin FROM Reservation WHERE id=?";
	private static final String UPDATE_RESERVATION_QUERY = "UPDATE Reservation SET id=?, client_id=?, vehicle_id=?, debut=?, fin=? WHERE id=?";
	
	/**
	 * On récupère les erreurs SQL levées et on utilise la requête SQL adéquate
	 * @param r
	 * @return l'id de l'entrée créée
	 * @throws DaoException
	 */
	public long create(Reservation r) throws DaoException {
		
		try (
				Connection connect = ConnectionManager.getConnection();
				PreparedStatement prepStat = connect.prepareStatement(CREATE_RESERVATION_QUERY);
			){
			prepStat.setInt(1, r.getClientId());
			prepStat.setInt(2, r.getVehicleId());
			prepStat.setString(3, r.getDebut().toString());
			prepStat.setString(4, r.getFin().toString());
			prepStat.execute();
			
		} catch (SQLException e) {
			throw new DaoException(e.getMessage());
		}
		return r.getId();
	}
	
	/**
	 * On récupère les erreurs SQL levées et on utilise la requête SQL adéquate
	 * @param r
	 * @return l'idée de l'entrée mise à jour
	 * @throws DaoException
	 */
	public long update(Reservation r) throws DaoException {
		
		try (
				Connection connect = ConnectionManager.getConnection();
				PreparedStatement prepStat = connect.prepareStatement(UPDATE_RESERVATION_QUERY);
			){
			prepStat.setInt(1, r.getId());
			prepStat.setInt(2, r.getClientId());
			prepStat.setInt(3, r.getVehicleId());
			prepStat.setString(4, r.getDebut().toString());
			prepStat.setString(5, r.getFin().toString());
			prepStat.setInt(6, r.getId());
			prepStat.execute();
			
		} catch (SQLException e) {
			throw new DaoException(e.getMessage());
		}
		return r.getId();
	}
	
	/**
	 * On récupère les erreurs SQL levées et on utilise la requête SQL adéquate
	 * @param id
	 * @return l'id de l'entrée supprimée
	 * @throws DaoException
	 */
	public long deleteById(int id) throws DaoException {
		
		try (
		    Connection connect = ConnectionManager.getConnection();
		    PreparedStatement prepStat = connect.prepareStatement(DELETE_RESERVATION_QUERY);
		    ){
			prepStat.setInt(1, id);
			prepStat.executeUpdate();
			
		} catch(SQLException e) {
			throw new DaoException(e.getMessage());
		}		
		return id;
	}
	
	/**
	 * On récupère les erreurs SQL levées et on utilise la requête SQL adéquate
	 * @param clientId
	 * @return la liste des réservations avec le clientId en paramètre
	 * @throws DaoException
	 */
	public List<Reservation> findResaByClientId(long clientId) throws DaoException {
		
		 List<Reservation> result = new ArrayList<>();
		 
		 try (
			 Connection connection = ConnectionManager.getConnection();
			 PreparedStatement prepStat = connection.prepareStatement(FIND_RESERVATIONS_BY_CLIENT_QUERY);
		 ){
			 prepStat.setInt(1, (int) clientId);
			 ResultSet resultSet = prepStat.executeQuery();
			 
			 while(resultSet.next()) {
				 Reservation r = new Reservation();
				 r.setVehicle(vDap.findById(resultSet.getInt("vehicle_id")));
				 result.add(reservation(resultSet, r));
			 }
			 resultSet.close();
			 
		 } catch (SQLException e) {
			 throw new DaoException("Une erreur client est survenue :" + e.getMessage());
		 }
		 return result;
	}
	
	/**
	 * On récupère les erreurs SQL levées et on utilise la requête SQL adéquate
	 * @param vehicleId
	 * @return la liste des réservations avec le véhiculeId en paramètre
	 * @throws DaoException
	 */
	public List<Reservation> findResaByVehicleId(long vehicleId) throws DaoException {
		
		List<Reservation> result = new ArrayList<>();
		
		 try (
			 Connection connection = ConnectionManager.getConnection();
			 PreparedStatement prepStat = connection.prepareStatement(FIND_RESERVATIONS_BY_VEHICLE_QUERY);
		 ){
			 prepStat.setInt(1, (int) vehicleId);
			 ResultSet resultSet = prepStat.executeQuery();

			 while(resultSet.next()) {
				 Reservation r = new Reservation();
				 r.setClient(cDao.findById(resultSet.getInt("client_id")));
				 result.add(reservation(resultSet, r));
			 }
			 resultSet.close();
			 
		 } catch (SQLException e) {
			 throw new DaoException("Une erreur véhicule est survenue :" + e.getMessage());
		 }
		 return result;
	}
	
	/**
	 * On récupère les erreurs SQL levées et on utilise la requête SQL adéquate
	 * @param id
	 * @return la réservation avec cette id
	 * @throws DaoException
	 */
	public Reservation findById(int id) throws DaoException {
		Reservation r = new Reservation();
		
		try (
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(FIND_RESERVATION_QUERY);
		){
			preparedStatement.setInt(1, id);
			ResultSet resultSet = preparedStatement.executeQuery();
			
			if (resultSet.next()){
				r.setId(id);
				r.setVehicle(vDap.findById(resultSet.getInt("vehicle_id")));
				r.setClient(cDao.findById(resultSet.getInt("client_id")));
				r.setDebut(LocalDate.parse(resultSet.getString("debut"), format));
				r.setFin(LocalDate.parse(resultSet.getString("fin"), format));
			}
			resultSet.close();
			
		} catch (SQLException e) {
			throw new DaoException("Une erreur est survenue : " + e.getMessage());
		}
		return r;
	}
	
	/**
	 * On récupère les erreurs SQL levées et on utilise la requête SQL adéquate
	 * @return la liste de toutes les réservations
	 * @throws DaoException
	 */
	public List<Reservation> findAll() throws DaoException {
		
		 List<Reservation> result = new ArrayList<>();
		 
		 try (
			 Connection connection = ConnectionManager.getConnection();
			 PreparedStatement prepStat = connection.prepareStatement(FIND_RESERVATIONS_QUERY);
		 ){
			 ResultSet resultSet = prepStat.executeQuery();
			 
			 while(resultSet.next()) {
				 Reservation r = new Reservation();
				 r.setClient(cDao.findById(resultSet.getInt("client_id")));
				 r.setVehicle(vDap.findById(resultSet.getInt("vehicle_id")));
				 result.add(reservation(resultSet, r));
			 }
			 resultSet.close();
			 
		 } catch (SQLException e) {
			 throw new DaoException("Une erreur DAO est survenue :" + e.getMessage());
		 }
		 return result;
	}
	
	/**
	 * Cette fonction permet de réduire le nombre de lignes des fonctions précédentes
	 * @param resultSet
	 * @param r
	 * @return on retourne la réservation avec les champs complétés
	 * @throws SQLException
	 */
	private Reservation reservation(ResultSet resultSet, Reservation r) throws SQLException{
		 r.setId(resultSet.getInt("id"));
		 r.setDebut(LocalDate.parse(resultSet.getString("debut"), format));
		 r.setFin(LocalDate.parse(resultSet.getString("fin"), format));
		 return r;
	}
}
