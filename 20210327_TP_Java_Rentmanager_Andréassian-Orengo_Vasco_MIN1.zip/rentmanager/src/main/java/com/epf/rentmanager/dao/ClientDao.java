package com.epf.rentmanager.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import com.epf.rentmanager.exceptions.DaoException;
import com.epf.rentmanager.model.Client;
import com.epf.rentmanager.persistence.ConnectionManager;

public class ClientDao {
	
	private static ClientDao instance = null;
	private ClientDao() {}
	public static ClientDao getInstance() {
		if(instance == null) {
			instance = new ClientDao();
		}
		return instance;
	}
	
	private DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ss");
	
	private static final String CREATE_CLIENT_QUERY = "INSERT INTO Client(nom, prenom, email, naissance) VALUES(?, ?, ?, ?);";
	private static final String DELETE_CLIENT_QUERY = "DELETE FROM Client WHERE id=?;";
	private static final String FIND_CLIENT_QUERY = "SELECT nom, prenom, email, naissance FROM Client WHERE id=?;";
	private static final String FIND_CLIENTS_QUERY = "SELECT id, nom, prenom, email, naissance FROM Client;";
	private static final String UPDATE_CLIENT_QUERY = "UPDATE Client SET id=?, nom=?, prenom=?, email=?, naissance=? WHERE id=?";
	private static final String LIST_CLIENTS_EMAIL_QUERY = "SELECT email FROM Client;";
	
	/**
	 * On récupère les erreurs SQL levées et on utilise la requête SQL adéquate
	 * @param c
	 * @return l'id de l'entrée créée
	 * @throws DaoException
	 */
	public long create(Client c) throws DaoException {
		
		try (
				Connection connection = ConnectionManager.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(CREATE_CLIENT_QUERY, Statement.RETURN_GENERATED_KEYS);
			){
			preparedStatement.setString(1, c.getNom());
			preparedStatement.setString(2, c.getPrenom());
			preparedStatement.setString(3, c.getEmail());
			preparedStatement.setString(4, (c.getNaissance()).toString());
			preparedStatement.executeUpdate();
			
			ResultSet resultSet = preparedStatement.getGeneratedKeys();
			if(resultSet.next()) {
				return resultSet.getInt(1);
			} else {
				throw new DaoException("Erreur dans la création du client.");
			}
			
		} catch (SQLException e) {
			throw new DaoException("Une erreur SQL est survenue : " + e.getMessage());
		}
	}
	
	/**
	 * On récupère les erreurs SQL levées et on utilise la requête SQL adéquate
	 * @param c
	 * @return l'id de l'entrée mise à jour
	 * @throws DaoException
	 */
	public long update(Client c) throws DaoException {
		
		try (
				Connection connection = ConnectionManager.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_CLIENT_QUERY, Statement.RETURN_GENERATED_KEYS);
			){
			preparedStatement.setInt(1, c.getId());
			preparedStatement.setString(2, c.getNom());
			preparedStatement.setString(3, c.getPrenom());
			preparedStatement.setString(4, c.getEmail());
			preparedStatement.setString(5, (c.getNaissance()).toString());
			preparedStatement.setInt(6, c.getId());
			preparedStatement.executeUpdate();
			
			ResultSet resultSet = preparedStatement.getGeneratedKeys();
			if(resultSet.next()) {
				return resultSet.getInt(1);
			} else {
				throw new DaoException("Erreur dans la mise à jour du client.");
			}
			
		} catch (SQLException e) {
			throw new DaoException("Une erreur SQL est survenue : " + e.getMessage());
		}
	}
	
	/**
	 * On récupère les erreurs SQL levées et on utilise la requête SQL adéquate
	 * @param id
	 * @return l'id de l'entrée supprimée
	 * @throws DaoException
	 */
	public long deleteById(int id) throws DaoException {
		try (
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(DELETE_CLIENT_QUERY);
			){
			preparedStatement.setInt(1, id);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			throw new DaoException(e.getMessage());
		}
		return id;
	}
	
	/**
	 * On récupère les erreurs SQL levées et on utilise la requête SQL adéquate
	 * @param id
	 * @return l'entrée trouvée
	 * @throws DaoException
	 */
	public Client findById(int id) throws DaoException {
		Client c = new Client();
		try (
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(FIND_CLIENT_QUERY);
		){
			preparedStatement.setInt(1, id);
			ResultSet resultSet = preparedStatement.executeQuery();
			
			if (resultSet.next()){
				c.setId(id);
				c.setNom(resultSet.getString("nom"));
				c.setPrenom(resultSet.getString("prenom"));
				c.setEmail(resultSet.getString("email"));
				c.setNaissance(LocalDate.parse(resultSet.getString("naissance"), format));
			}
			resultSet.close();
			
		} catch (SQLException e) {
			throw new DaoException(e.getMessage());
		}
		return c;
	}
	
	/**
	 * On récupère les erreurs SQL levées et on utilise la requête SQL adéquate
	 * @return la liste des entrées trouvées
	 * @throws DaoException
	 */
	public List<Client> findAll() throws DaoException {
		List<Client> result = new ArrayList<>();
		try {
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(FIND_CLIENTS_QUERY);
			
			ResultSet resultSet = preparedStatement.executeQuery();
			while (resultSet.next()){
				Client client = new Client();
				client.setId(resultSet.getInt("id"));
				client.setNom(resultSet.getString("nom"));
				client.setPrenom(resultSet.getString("prenom"));
				client.setEmail(resultSet.getString("email"));
				client.setNaissance(LocalDate.parse(resultSet.getString("naissance"), format));
				result.add(client);
			}
			resultSet.close();
			preparedStatement.close();
			connection.close();
			
		} catch (SQLException e) {
			throw new DaoException("Une erreur DAO est survenue : " + e.getMessage());
		}
		return result;
	}
	
	/**
	 * On récupère les erreurs SQL levées et on utilise la requête SQL adéquate
	 * @return la liste de tous les emails
	 * @throws DaoException
	 */
	public List<String> getEmails() throws DaoException {
		List<String> result = new ArrayList<>();
		try (
			Connection connect = ConnectionManager.getConnection();
			PreparedStatement prepStat = connect.prepareStatement(LIST_CLIENTS_EMAIL_QUERY);
			){
			ResultSet resultSet = prepStat.executeQuery();
			while (resultSet.next()) {
				result.add(resultSet.getString("email"));
			}
			resultSet.close();
		} catch (SQLException e) {
			throw new DaoException("Une ereur SQL est survenue : " + e.getMessage());
		}
		return result;
	}

}
