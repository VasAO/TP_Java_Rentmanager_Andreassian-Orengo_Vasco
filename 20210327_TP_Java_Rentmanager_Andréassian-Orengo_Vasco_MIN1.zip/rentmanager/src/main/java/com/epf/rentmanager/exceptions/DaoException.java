package com.epf.rentmanager.exceptions;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

import com.epf.rentmanager.dao.ClientDao;
import com.epf.rentmanager.dao.ReservationDao;
import com.epf.rentmanager.model.Client;
import com.epf.rentmanager.model.Reservation;
import com.epf.rentmanager.model.Vehicle;

public class DaoException extends Exception {
	
	public static DaoException instance = null;
	
	final private int dureeMaxResa = 6;
	final private int nbMaxPlaces = 9;
	final private int nbMinPlaces = 1;
	final private int longMinNom = 3;
	final private int longMinPrenom = 3;
	
	private DaoException() {}
	
	
	public static DaoException getInstance() {
		if (instance == null) {
			instance = new DaoException();
		}
		return instance;
	}
	
	public DaoException(String msg) {
		super(msg);
	}

	private ReservationDao rDao = ReservationDao.getInstance();
	private ClientDao cDao = ClientDao.getInstance();
	
	/**
	 * @param c
	 * @throws DaoException
	 */
	public void checkClient(Client c) throws DaoException {
		
		checkEmail(cDao.getEmails(), c.getEmail());
		checkUpdateClient(c);
	}
	
	/**
	 * @param c
	 * @throws DaoException
	 */
	public void checkUpdateClient(Client c) throws DaoException {
		
		checkAge(c.getNaissance());
		checkNames(c.getNom(), c.getPrenom());
	}
	
	/**
	 * On vérfie que l'utilisateur a bien 18 ans.
	 * @param naissance
	 * @throws DaoException
	 */
	public void checkAge(LocalDate naissance) throws DaoException {
		
		String birth = naissance.until(LocalDate.now()).toString();
		
		if (Integer.parseInt(birth.substring(1, birth.indexOf("Y"))) < 18) {
			throw new DaoException("L'utilisateur n'a pas 18 ans.");
		}
	}
	
	/**
	 * On vérifie que le nom et le prénom de l'utilisateur sont suffisament longs
	 * @param nom
	 * @param prenom
	 * @throws DaoException
	 */
	public void checkNames(String nom, String prenom) throws DaoException {
		
		if(nom.length() < longMinNom || prenom.length() < longMinPrenom) {
			throw new DaoException("Les noms et prénoms doivent comporter plus de deux lettres.");
		}
	}
	
	/**
	 * On vérifie que l'email n'existe pas déjà.
	 * @param emails
	 * @param email
	 * @throws DaoException
	 */
	public void checkEmail(List<String> emails, String email) throws DaoException{
		
		for (int i = 0; i < emails.size(); i ++) {
			if (email.equals(emails.get(i))) {
				throw new DaoException("Il existe déjà un compte avec cet email.");
			}
		}
	}
	
	/**
	 * @param v
	 * @throws DaoException
	 */
	public void checkVehicle(Vehicle v) throws DaoException{
		
		checkNbPlaces(v.getNb_places());
	}
	
	/**
	 * On vérifie que le nombre de place est possible.
	 * @param nb_places
	 * @throws DaoException
	 */
	public void checkNbPlaces(short nb_places) throws DaoException {
		
		if (nb_places >= nbMaxPlaces || nb_places <= nbMinPlaces) {
			throw new DaoException("Le nombre de place doit être inférieur à 10."); 
		}
	}
	
	/**
	 * @param r
	 * @throws DaoException
	 */
	public void checkRent(Reservation r) throws DaoException {
		
		checkUpdateRent(r);
		checkRentSameDay(rDao.findResaByVehicleId(r.getVehicleId()), r.getDebut(), r.getFin());
		
		List <Reservation> rList = rDao.findResaByVehicleId(r.getVehicleId());
		rList.add(r);
		checkRentSerial(rList);
	}
	
	/**
	 * @param r
	 * @throws DaoException
	 */
	public void checkUpdateRent(Reservation r) throws DaoException {
		checkRentDates(r.getDebut(),r.getFin());
		checkRentDuration(r.getDebut(), r.getFin());
	}
	
	/**
	 * On vérifie que la durée de réservation ne dépasse pas la durée maximale.
	 * @param debut
	 * @param fin
	 * @throws DaoException
	 */
	public void checkRentDuration(LocalDate debut, LocalDate fin) throws DaoException {
		
		if (debut.until(fin, ChronoUnit.DAYS) > dureeMaxResa) {
			throw new DaoException("Un véhicule ne peut pas être réservé pendant plus de 7 jours.");
		}
	}
	
	/**
	 * On vérifie qu'avec cette réservation, le temps d'indisponibilité de la voiture ne dépasse pas 30 jours.
	 * @param rList
	 * @throws DaoException
	 */
	public void checkRentSerial(List<Reservation> rList) throws DaoException {
		
		int nbResa = rList.size();
		
		if (nbResa > 4) {
			int sommeJours = (int) rList.get(nbResa - 1).getDebut().until(rList.get(nbResa - 1).getFin(), ChronoUnit.DAYS) + 1;
			for (int i = nbResa - 1; i > 0; i --) {
				if ((rList.get(i)).getDebut().equals(rList.get(i - 1).getFin().plusDays(1))) {
					sommeJours = sommeJours + (int) rList.get(i - 1).getDebut().until(rList.get(i - 1).getFin(), ChronoUnit.DAYS) + 1;
				}
				else {
					break;
				}
			}
			if (sommeJours > 30) {
				throw new DaoException("Impossible de réserver une voiture à cette date là, essayez un jour plus tard.");
			}
		}
	}
	
	/**
	 * On vérifie que la date de fin est ultérieure à la date de début.
	 * @param debut
	 * @param fin
	 * @throws DaoException
	 */
	public void checkRentDates(LocalDate debut, LocalDate fin) throws DaoException {
		
		if (debut.isAfter(fin)) {
			throw new DaoException("La date de début est ultérieure à la date de fin.");
		}
	}
	
	/**
	 * On vérifie qu'une autre réservation ne réserve pas la voiture aux mêmes dates.
	 * @param rList
	 * @param debut
	 * @param fin
	 * @throws DaoException
	 */
	public void checkRentSameDay(List<Reservation> rList, LocalDate debut, LocalDate fin) throws DaoException{
		
		for (int i = 0; i < rList.size(); i++) {
			
			if (
				(debut.isBefore(rList.get(i).getFin()) && fin.isAfter(rList.get(i).getFin())) ||
				(debut.isBefore(rList.get(i).getDebut()) && fin.isAfter(rList.get(i).getDebut())) ||
				(debut.isBefore(rList.get(i).getDebut()) && fin.isAfter(rList.get(i).getFin())) ||
				(debut.isAfter(rList.get(i).getDebut()) && fin.isBefore(rList.get(i).getFin())) ||
				(debut.isEqual(rList.get(i).getDebut()) || debut.isEqual(rList.get(i).getFin()) ||
						fin.isEqual(rList.get(i).getDebut()) || fin.isEqual(rList.get(i).getFin()))
				){
				throw new DaoException("Cette réservation chevauche une réservation déjà existante.");
			}
		}
	}
	
	public void checkDeleteRent(int id) throws DaoException {
		if (rDao.findById(id) == null) {
			throw new DaoException("Impossible de détruire un client inexistant.");
		}
	}
}
