package com.epf.rentmanager.ui;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.epf.rentmanager.exceptions.ServiceException;
import com.epf.rentmanager.service.ClientService;
import com.epf.rentmanager.service.RentService;

@WebServlet("/users/details")
public class ClientDetailsServlet extends HttpServlet{
	
	private ClientService cs = ClientService.getInstance();
	private RentService rs = RentService.getInstance();
	
	protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
		
		final RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/users/details.jsp");
		
		try {
			request.setAttribute("client", cs.findById(Integer.parseInt(request.getParameter("id"))));
			request.setAttribute("rents", rs.findResaByClientId(Integer.parseInt(request.getParameter("id"))));
		} catch (final ServiceException e) {
			request.setAttribute("error", e.getMessage());
			dispatcher.forward(request,  response);	
		}
		dispatcher.forward(request,  response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
