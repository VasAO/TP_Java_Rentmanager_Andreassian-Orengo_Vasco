package com.epf.rentmanager.model;

import java.time.LocalDate;

public class Reservation {
	private int id;
	private Client client = new Client();
	private Vehicle vehicle = new Vehicle();
	private LocalDate debut;
	private LocalDate fin;
	
	// Constructors
	public Reservation(int id, Vehicle v, Client c, LocalDate debut, LocalDate fin) {
		this(v, c, debut, fin);
		this.id = id;
	}
	
	public Reservation(Vehicle v, Client c, LocalDate debut, LocalDate fin) {
		client.equals(c);
		vehicle.equals(v);
		this.debut = debut;
		this.fin = fin;
	}
	
	public Reservation() {
		
	}
	
	// Getters
	public int getId() {
		return id;
	}
	
	public int getClientId() {
		return client.getId();
	}
	
	public String getClientName() {
		return client.getNom();
	}
	
	public String getClientSurname() {
		return client.getPrenom();
	}
	
	public String getClientEmail() {
		return client.getEmail();
	}
	
	public LocalDate getClientBirth() {
		return client.getNaissance();
	}
	
	public int getVehicleId() {
		return vehicle.getId();
	}
	
	public String getVehicleModele() {
		return vehicle.getModele();
	}
	
	public String getVehicleConstr() {
		return vehicle.getConstructeur();
	}
	
	public int getVehicleSeats() {
		return vehicle.getNb_places();
	}
	public LocalDate getDebut() {
		return debut;
	}
	
	public LocalDate getFin() {
		return fin;
	}
	
	// Setters
	public void setId(int id) {
		this.id = id;
	}
	
	public void setClient(Client c) {
		client.equals(c);
	}
	
	public void setVehicle(Vehicle v) {
		vehicle.equals(v);
	}
	
	public void setClientId(int cid) {
		client.setId(cid);
	}
	
	public void setVehicleId(int vid) {
		vehicle.setId(vid);
	}
	
	public void setDebut(LocalDate debut) {
		this.debut = debut;
	}
	
	public void setFin(LocalDate fin) {
		this.fin = fin;
	}
}
