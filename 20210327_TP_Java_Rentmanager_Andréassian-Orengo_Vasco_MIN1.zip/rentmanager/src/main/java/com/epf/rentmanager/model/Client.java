package com.epf.rentmanager.model;

import java.time.LocalDate;

public class Client {
	private int id;
	private String nom;
	private String prenom;
	private String email;
	private LocalDate naissance;
	
	public Client() {}
	
	public Client(Client client) {
		this.id = client.id;
		this.nom = client.nom;
		this.prenom = client.prenom;
		this.email = client.email;
		this.naissance = client.naissance;
	}
	
	public Client(int id, String nom, String prenom, String email, LocalDate naissance) {
		this(nom, prenom, email, naissance);
		this.id = id;
	}
	
	public Client(String nom, String prenom, String email, LocalDate naissance) {
		this.nom = nom;
		this.prenom = prenom;
		this.email = email;
		this.naissance = naissance;
	}
	
	// Getters
	public int getId() {
		return id;
	}

	public String getNom() {
		return nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public String getEmail() {
		return email;
	}

	public LocalDate getNaissance() {
		return naissance;
	}
	
	// Setters
	public void setId(int id) {
		this.id = id;
	}
	
	public void setNom(String nom) {
		this.nom = nom;
	}
	
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public void setNaissance(LocalDate naissance) {
		this.naissance = naissance;
	}
	
	public void equals(Client c) {
		this.id = c.id;
		this.nom = c.nom;
		this.prenom = c.prenom;
		this.email = c.email;
		this.naissance = c.naissance;
	}
	
	public boolean isEqual(Client c) {
		if((this.nom).equals(c.nom) && (this.prenom).equals(c.prenom) && (this.email).equals(c.email) && (this.naissance).isEqual(c.naissance)) {
			return true;
		}
		else {
			return false;
		}
	}
 }
