package com.epf.rentmanager.ui;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.epf.rentmanager.exceptions.ServiceException;
import com.epf.rentmanager.model.Vehicle;
import com.epf.rentmanager.service.VehicleService;

@WebServlet("/cars/create")
public class VehicleCreateServlet extends HttpServlet {
	
	VehicleService vs = VehicleService.getInstance();
	ServiceException sException = ServiceException.getInstance();
	
	protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
		final RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/vehicles/create.jsp");
		dispatcher.forward(request,  response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		final RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/vehicles/create.jsp");
		
		try {
			sException.checkError(request.getParameter("constructeur"), request.getParameter("modele"), request.getParameter("nb_places"));
			
			Vehicle v = new Vehicle(request.getParameter("constructeur"), request.getParameter("modele"), Short.parseShort(request.getParameter("nb_places")));
			vs.create(v);
			
			response.sendRedirect("http://localhost:8080/rentmanager/cars");
		
		} catch (final ServiceException e) {
			request.setAttribute("error", e.getMessage());
			dispatcher.forward(request,  response);	
		}
	}
}
