package epf;

import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.mockito.Mockito;

import com.epf.rentmanager.dao.ClientDao;
import com.epf.rentmanager.dao.ReservationDao;
import com.epf.rentmanager.dao.VehicleDao;
import com.epf.rentmanager.exceptions.DaoException;
import com.epf.rentmanager.exceptions.ServiceException;
import com.epf.rentmanager.model.Client;
import com.epf.rentmanager.model.Reservation;
import com.epf.rentmanager.service.RentService;
import com.epf.rentmanager.service.VehicleService;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit test for simple App.
 */
public class AppTest 
    extends TestCase
{
    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
    public AppTest( String testName )
    {
        super( testName );
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite()
    {
        return new TestSuite( AppTest.class );
    }

    /**
     * Rigourous Test :-)
     */
    public void testApp()
    {
        assertTrue( true );
    }
    
    private DaoException daoException = DaoException.getInstance();
    private VehicleDao vehicleDao = VehicleDao.getInstance();
    private ClientDao clientDao = ClientDao.getInstance();
    private ReservationDao reservationDao = ReservationDao.getInstance();
    
    private DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy");
    
    public void test_checkClient_from_DaoException() {
    	Client c = new Client("Jean", "Jean", "jean.jean@email.com", LocalDate.parse("06-06-2008", format));
    	try {
    		daoException.checkClient(c);
    		fail("DaoException n'a pas été levée.");
    	} catch (DaoException e) {
    		assertTrue(true);
    	}
    }
    
    public void test_create_from_RentService_when_there_is_more_than_7_rent_days() {
    	
    	try {
    	  	Reservation rTest = new Reservation(vehicleDao.findById(3), clientDao.findById(1), LocalDate.parse("01-04-2021", format), LocalDate.parse("10-04-2021", format));
        	
    		RentService rsMock = Mockito.mock(RentService.class); 		
    		when(rsMock.create(rTest)).thenReturn(reservationDao.create(rTest));
    		
    		rsMock.create(rTest);
	    } catch (ServiceException e) {
			assertTrue(true);
		} catch (DaoException e) {
			fail(e.getMessage());
		}
    }
    
    public void test_findById_from_VehicleDao() {
    	
    	int test = 1;
    	
    	try {
    		assertTrue(test == vehicleDao.findById(test).getId());
    	} catch (DaoException e) {
    		fail(e.getMessage());
    	}
    }
    
    public void test_findById_from_VehicleService() {
    	
    	int test = 2;
    	
    	try {
    		VehicleService vsMock = Mockito.mock(VehicleService.class);    		
    		when(vsMock.findById(test)).thenReturn(vehicleDao.findById(test));
    		
    		assertTrue(test == vsMock.findById(test).getId());
    		
    	} catch (ServiceException e) {
    		fail(e.getMessage());
    	} catch (DaoException e) {
    		fail(e.getMessage());
    	}
    }
    
    public void test_deleteById_from_ReservationDao() {
    	
    	int idTest = 1;
    	
    	try {
			assertTrue(idTest == reservationDao.deleteById(idTest));
		} catch (DaoException e) {
    		fail(e.getMessage());
		}
    }
}
